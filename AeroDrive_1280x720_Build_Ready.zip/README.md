# AeroDrive Android project

This Android Studio project wraps the supplied AeroDrive HTML launcher in a landscape, immersive Android WebView app.

## Build the APK
1. Install Android Studio (current stable) on a computer.
2. Open this `AeroDriveAndroid` folder.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android version: Android 8.0 (API 26). The app requires internet access for the original HTML's CDN-hosted Tailwind, icon fonts, Google Fonts and remote album artwork.

## Notes
- The phone keypad opens Android's dialer with the entered number; it does not place calls automatically.
- External links such as Maps, Spotify and YouTube are handed to Android.
- Speed, RPM, OBD-II readings, FM tuner and HVAC controls in the supplied HTML are demonstration UI, not live vehicle telemetry or hardware controls. Real data/control requires compatible vehicle APIs/adapters and device-specific integration.
- No direct Android SDK/Gradle toolchain is bundled in this source archive.

## Head-unit layout profile
The included dashboard CSS is tuned for a 1280x720 landscape head unit, with a compact header/footer, reduced gauge footprint and tighter panel spacing. It also includes responsive fallbacks for nearby landscape resolutions. The native activity is locked to landscape and immersive full-screen mode.
